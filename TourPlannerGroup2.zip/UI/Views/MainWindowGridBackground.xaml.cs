﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for MainWindowGridBackground.xaml
    /// </summary>
    public partial class MainWindowGridBackground : UserControl
    {
        public MainWindowGridBackground()
        {
            InitializeComponent();
            
        }
    }
}
