﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for SettingPageMiddle.xaml
    /// </summary>
    public partial class SettingPageMiddle : Page
    {
        public SettingPageMiddle()
        {
            InitializeComponent();
        }
    }
}
