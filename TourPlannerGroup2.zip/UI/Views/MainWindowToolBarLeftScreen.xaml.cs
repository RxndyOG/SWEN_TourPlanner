﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for MainWindowToolBarLeftScreen.xaml
    /// </summary>
    public partial class MainWindowToolBarLeftScreen : UserControl
    {
        public MainWindowToolBarLeftScreen()
        {
            InitializeComponent();
        }
    }
}
