﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for DeleteWindowNothingHere.xaml
    /// </summary>
    public partial class DeleteWindowNothingHere : Page
    {
        public DeleteWindowNothingHere()
        {
            InitializeComponent();
        }
    }
}
