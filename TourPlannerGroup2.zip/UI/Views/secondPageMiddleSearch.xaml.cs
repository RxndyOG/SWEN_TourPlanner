﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for secondPageMiddleSearch.xaml
    /// </summary>
    public partial class secondPageMiddleSearch : Page
    {
        public secondPageMiddleSearch()
        {
            InitializeComponent();
        }
    }
}
