﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for SettingsPage1Right.xaml
    /// </summary>
    public partial class SettingsPage1Right : Page
    {
        public SettingsPage1Right()
        {
            InitializeComponent();
        }
    }
}
