﻿using System.Windows.Controls;

namespace UI.Views
{
    /// <summary>
    /// Interaction logic for BlockUserControl.xaml
    /// </summary>
    public partial class BlockUserControl : UserControl
    {
        public BlockUserControl()
        {
            InitializeComponent();
        }
    }
}
